package com.insper.user.common;

import com.insper.user.user.UserModel;
import com.insper.user.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MongoUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserModel userMongo = userRepository.findByEmail(username);


        if (userMongo == null) {
            throw new UsernameNotFoundException(username);
        }

        return User.builder()
                .username(userMongo.getEmail())
                .password(userMongo.getPassword())
                .roles(userMongo.getRoles().toArray(String[]::new))
                .build();
    }

}
