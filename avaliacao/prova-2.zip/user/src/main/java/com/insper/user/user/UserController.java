package com.insper.user.user;

import com.insper.user.user.dto.ReturnUserDTO;
import com.insper.user.user.dto.SaveUserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/teste")
    public String oi() {
        return "Oi!";
    }

    @PostMapping
    public ReturnUserDTO saveUser(@RequestBody SaveUserDTO saveUser) {
        return userService.saveUser(saveUser);
    }

}
