package com.insper.user.user;

import com.insper.user.user.dto.ReturnUserDTO;
import com.insper.user.user.dto.SaveUserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public ReturnUserDTO saveUser(SaveUserDTO saveUser) {

        if (userRepository.existsByEmail(saveUser.getEmail())) {
            throw new UserAlreadyExistsException();
        }
        UserModel userModel = new UserModel();
        userModel.setPassword(passwordEncoder.encode(saveUser.getPassword()));
        userModel.setEmail(saveUser.getEmail());
        userModel.setRoles(saveUser.getRoles());
        userModel.setCpf(saveUser.getCpf());
        return ReturnUserDTO.convert(userRepository.save(userModel));
    }

}
