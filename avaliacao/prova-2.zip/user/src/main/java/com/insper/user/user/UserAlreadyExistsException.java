package com.insper.user.user;

public class UserAlreadyExistsException extends RuntimeException {
}
