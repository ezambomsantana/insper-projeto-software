package com.insper.user.user.dto;

import com.insper.user.user.UserModel;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ReturnUserDTO {
    private String email;
    private String password;
    private String cpf;
    private List<String> roles;

    public static ReturnUserDTO convert(UserModel userMongo) {
        ReturnUserDTO userDTO = new ReturnUserDTO();
        userDTO.setEmail(userMongo.getEmail());
        userDTO.setRoles(userMongo.getRoles());
        userDTO.setPassword(userMongo.getPassword());
        userDTO.setCpf(userMongo.getCpf());
        return userDTO;
    }

}
