package com.prova.insper.entregas;

import com.prova.insper.entregas.dto.TotalEntregasEntregadorDTO;
import com.prova.insper.entregas.dto.EntregaDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EntregasService {

    @Autowired
    private EntregasRepository entregasRepository;

    public EntregaDTO saveEntrega(EntregaDTO entregaDTO) {
        entregaDTO.setIdentifier(UUID.randomUUID().toString());
        Entrega venda = Entrega.convert(entregaDTO);
        return EntregaDTO.convert(entregasRepository.save(venda));
    }

    public List<EntregaDTO> getEntregas() {
        return entregasRepository
                .findAll()
                .stream()
                .map(v -> EntregaDTO.convert(v))
                .collect(Collectors.toList());
    }

    public EntregaDTO getEntrega(String identifier) {
        List<EntregaDTO> entregas = entregasRepository
                .findAll()
                .stream()
                .filter(v -> v.getIdentifier().equals(identifier))
                .map(v -> EntregaDTO.convert(v))
                .collect(Collectors.toList());
        if (!entregas.isEmpty()) {
            return entregas.get(0);
        } else {
            return null;
        }
    }

    public void deleteEntregas(String identifier) {
        List<Entrega> entregas = entregasRepository
                .findAll()
                .stream()
                .filter(v -> v.getIdentifier().equals(identifier))
                .collect(Collectors.toList());
        if (!entregas.isEmpty()) {
            entregasRepository.delete(entregas.get(0));
        }
    }

    public List<EntregaDTO> getEntregasMaiorMinimo(Float minimo) {
        List<EntregaDTO> entregas = entregasRepository
                .findAll()
                .stream()
                .filter(v -> v.getDistancia() > minimo)
                .map(v -> EntregaDTO.convert(v))
                .collect(Collectors.toList());
        return entregas;
    }

    public List<TotalEntregasEntregadorDTO> getEntregasMaiorMinimoPorEntregador(Float minimo, List<String> cpfs) {
        return null;
    }
}
