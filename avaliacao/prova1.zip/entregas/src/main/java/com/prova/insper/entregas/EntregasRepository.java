package com.prova.insper.entregas;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EntregasRepository extends JpaRepository<Entrega, Integer> {
}
